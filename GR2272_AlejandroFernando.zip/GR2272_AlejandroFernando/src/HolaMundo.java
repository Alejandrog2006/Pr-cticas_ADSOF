/**
 * Esta clase muestra en pantalla "Hola Mundo"
 * Autor: Alejandro González y Fernando Blanco
 * Version: 1.0
 * Nombre del fichero: HolaMundo.java
 */
public class HolaMundo {
	/**
	 * Punto de entrada de la aplicación.
	 * El programa muestra en pantalla "Hola Mundo".
	 * @param args Argumentos de línea de comandos
	 */
	public static void main(String[] args) {
		// Muestra en pantalla "Hola Mundo"
		System.out.println("Hola Mundo");
	}
}
